


package com.user.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LoginSignUpApplication {

	public static void main(String[] args) {
		SpringApplication.run(LoginSignUpApplication.class, args);
	System.out.println("Congrats,Code is running succssfully.");
	
	}

}
