export class Bookings {

    id:number;
    name:string;
    seats:number;
    date:string;
    mobileNumber:string;
}
