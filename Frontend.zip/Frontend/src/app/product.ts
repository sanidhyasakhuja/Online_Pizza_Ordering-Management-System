export class Product {

    id:number;
    name:string;
    price:number;
    description:string;
    picByte:string;
    retrievedImage: string;
    isAdded: boolean;
}
