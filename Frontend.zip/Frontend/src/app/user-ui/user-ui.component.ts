import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-ui',
  templateUrl: './user-ui.component.html',
  styleUrls: ['./user-ui.component.css']
})
export class UserUiComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
