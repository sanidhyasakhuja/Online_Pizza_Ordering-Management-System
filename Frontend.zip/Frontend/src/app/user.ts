export class User {

    
    id:number;
    emailid:string ;
    username:string ;
    password:string ;

   constructor(){}
}


